# Express

## install
Sebelum di run bisa di install untuk package nya dulu

`npm i` atau `yarn`

### untuk running server node
`npm run start:node` atau `yarn start:node`

### untuk running server expresss
`npm run start:express` atau `yarn start:express`